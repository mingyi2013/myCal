#' Title
#'
#' @param x A numeric vector for calclulation
#' @param f A funcation to apply for x
#'
#' @return Restult of the calculatation
#' @export
#'
#' @examples my_calc(1:10, mean)

my_calc <- function(x, f) {
  f(x)
}
